Global Styles:

Font: The site uses a sans-serif font for a clean and modern look.
Colors: The primary colors are shades of blue and gray, providing a professional and trustworthy feel.
Spacing: Generous use of padding and margins to create a spacious layout.
Animations: Subtle animations using framer-motion for elements like headings, buttons, and icons to enhance user interaction.
Header (Navigation):

Sticky Header: The navigation bar is fixed at the top and changes background color when scrolled.
Responsive Menu: The menu adapts to different screen sizes, with a hamburger menu for mobile devices.
Hero Section:

Background: A dotted background with a semi-transparent overlay that moves with scroll.
Typography: Large, bold headings and subheadings with smooth fade-in animations.
Buttons: Prominent call-to-action buttons with hover effects.
Sections (How It Works, Key Features, CTA):

Backgrounds: Each section has a light background with a slight blur effect for a soft look.
Cards: Features and steps are displayed in card-like components with shadows and hover effects.
Icons: Use of lucide-react icons to visually represent features and steps.
Footer:

Simple and Clean: A minimalistic footer with essential links and information