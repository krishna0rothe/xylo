import React from 'react'
import { Register } from './components/Register'
import LandingPage from './pages/LandingPage'

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <LandingPage />
    </div>
  )
}

export default App