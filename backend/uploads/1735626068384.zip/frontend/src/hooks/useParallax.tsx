import { useCallback, RefObject } from 'react'

const useParallax = (ref: RefObject<HTMLElement>) => {
  const handleScroll = useCallback(() => {
    const scrolled = window.scrollY
    if (ref.current) {
      const elements = ref.current.querySelectorAll('[data-parallax]')
      elements.forEach((el) => {
        const speed = parseFloat(el.getAttribute('data-parallax') || '0.1')
        const yPos = -(scrolled * speed)
        el.setAttribute('style', `transform: translate3d(0, ${yPos}px, 0)`)
      })
    }
  }, [ref])

  return { handleScroll }
}

export default useParallax

