import { useEffect, useState } from 'react'
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet'
import { LatLng, Icon } from 'leaflet'
import { Label } from './ui/label'
import { Input } from './ui/input'

// Import Leaflet CSS
import 'leaflet/dist/leaflet.css'

// Create custom icon
const customIcon = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41]
})

interface MapLocationPickerProps {
  onLocationSelect: (lat: number, lng: number) => void
}

function LocationMarker({ onLocationSelect }: MapLocationPickerProps) {
  const [position, setPosition] = useState<LatLng | null>(null)
  const map = useMap()
  
  useEffect(() => {
    map.locate()

    const handleLocationFound = (e: any) => {
      setPosition(e.latlng)
      map.flyTo(e.latlng, 13)
      onLocationSelect(e.latlng.lat, e.latlng.lng)
    }

    map.on('locationfound', handleLocationFound)
    
    return () => {
      map.off('locationfound', handleLocationFound)
    }
  }, [map, onLocationSelect])

  const handleMapClick = (e: any) => {
    setPosition(e.latlng)
    onLocationSelect(e.latlng.lat, e.latlng.lng)
  }

  useEffect(() => {
    map.on('click', handleMapClick)
    return () => {
      map.off('click', handleMapClick)
    }
  }, [map])

  return position === null ? null : (
    <Marker 
      position={position}
      icon={customIcon}
      draggable={true}
      eventHandlers={{
        dragend: (e) => {
          const marker = e.target
          const position = marker.getLatLng()
          setPosition(position)
          onLocationSelect(position.lat, position.lng)
        },
      }}
    />
  )
}

export function MapLocationPicker({ onLocationSelect }: MapLocationPickerProps) {
  const [coordinates, setCoordinates] = useState({ lat: '', lng: '' })
  const defaultCenter = { lat: 20.5937, lng: 78.9629 } // India's center

  const handleLocationUpdate = (lat: number, lng: number) => {
    setCoordinates({
      lat: lat.toFixed(6),
      lng: lng.toFixed(6)
    })
    onLocationSelect(lat, lng)
  }

  return (
    <div className="space-y-4">
      <div className="h-[300px] rounded-lg overflow-hidden shadow-md relative">
        <MapContainer
          center={defaultCenter}
          zoom={5}
          className="h-full w-full z-0"
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <LocationMarker onLocationSelect={handleLocationUpdate} />
        </MapContainer>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="latitude">Latitude</Label>
          <Input
            id="latitude"
            value={coordinates.lat}
            readOnly
            placeholder="Click on map to set latitude"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="longitude">Longitude</Label>
          <Input
            id="longitude"
            value={coordinates.lng}
            readOnly
            placeholder="Click on map to set longitude"
          />
        </div>
      </div>
    </div>
  )
}