import React, { useState, useEffect } from 'react';
import { Menu, X } from 'react-feather';

const Navigation: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/70 backdrop-blur-md shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <a href="/" className="text-2xl font-bold text-blue-600">
            FixMyRide
          </a>
          <div className="hidden md:flex space-x-6">
            <NavLink href="#how-it-works">How It Works</NavLink>
            <NavLink href="#features">Features</NavLink>
            <NavLink href="#contact">Contact</NavLink>
          </div>
          <button
            className="md:hidden text-blue-600"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        {isMenuOpen && (
          <div className="md:hidden py-4 bg-white/90 backdrop-blur-sm rounded-lg mt-2">
            <NavLink href="#how-it-works" mobile>How It Works</NavLink>
            <NavLink href="#features" mobile>Features</NavLink>
            <NavLink href="#contact" mobile>Contact</NavLink>
          </div>
        )}
      </div>
    </nav>
  );
};

const NavLink: React.FC<{ href: string; children: React.ReactNode; mobile?: boolean }> = ({ href, children, mobile = false }) => (
  <a
    href={href}
    className={`text-gray-700 hover:text-blue-600 transition-colors duration-300 ${
      mobile ? 'block py-2 px-4 hover:bg-gray-50' : ''
    }`}
  >
    {children}
  </a>
);

export default Navigation;

