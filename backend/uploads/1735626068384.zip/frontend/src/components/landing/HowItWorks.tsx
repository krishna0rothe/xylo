import React from 'react';
import { motion } from 'framer-motion';
import { Wrench, MapPin, Car } from 'lucide-react';

const steps = [
  {
    title: 'Request Assistance',
    description: 'Share your vehicle issue and location.',
    icon: Wrench,
  },
  {
    title: 'Choose a Mechanic',
    description: 'Review profiles, ratings, and response times.',
    icon: MapPin,
  },
  {
    title: 'Get Back on the Road',
    description: 'Experience efficient on-site repairs.',
    icon: Car,
  },
];

const HowItWorks: React.FC = () => {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-white/70 backdrop-blur-sm" />
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
          Getting Help is as Easy as 1-2-3
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className="bg-white/80 backdrop-blur-sm p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <div className="flex items-center justify-center mb-4">
                <step.icon className="w-12 h-12 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">{step.title}</h3>
              <p className="text-gray-600 text-center">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;

