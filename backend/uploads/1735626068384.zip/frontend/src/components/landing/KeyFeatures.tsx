import React from 'react';
import { motion } from 'framer-motion';
import { Clock, MapPin, Star, Shield } from 'lucide-react';

const features = [
  {
    title: 'Instant Assistance',
    description: 'Request a mechanic in seconds.',
    icon: Clock,
  },
  {
    title: 'Precise Location Tracking',
    description: 'Share your exact location for faster service.',
    icon: MapPin,
  },
  {
    title: 'Trusted Mechanics',
    description: 'Browse expertise, ratings, and reviews.',
    icon: Star,
  },
  {
    title: 'Secure & Scalable',
    description: 'Powered by Express.js for seamless and reliable service.',
    icon: Shield,
  },
];

const KeyFeatures: React.FC = () => {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-white/70 backdrop-blur-sm" />
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
          Why Choose FixMyRide?
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-white/80 backdrop-blur-sm p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              <div className="flex items-center justify-center mb-4">
                <feature.icon className="w-12 h-12 text-blue-600 group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">{feature.title}</h3>
              <p className="text-gray-600 text-center">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeyFeatures;

