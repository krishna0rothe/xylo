import React from 'react';
import { motion } from 'framer-motion';
import { Wrench, MapPin, Car } from 'lucide-react';

const CallToAction: React.FC = () => {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/80 to-purple-600/80 backdrop-blur-sm" />
      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-3xl md:text-4xl font-bold mb-4 text-white"
        >
          Stranded? We've Got You Covered.
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-xl mb-8 text-white/90"
        >
          Join thousands of happy drivers who rely on FixMyRide for fast, reliable help.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="space-x-4"
        >
          <button className="bg-white/90 backdrop-blur-sm text-blue-600 px-6 py-3 rounded-full text-lg font-semibold hover:bg-white transition-colors duration-300">
            Request Assistance Now
          </button>
          <button className="bg-transparent border-2 border-white/90 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-white/10 transition-colors duration-300">
            Sign Up as a Mechanic
          </button>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="mt-12 flex justify-center space-x-8"
        >
          <Wrench className="w-12 h-12 text-white/90 animate-bounce" />
          <MapPin className="w-12 h-12 text-white/90 animate-bounce" style={{ animationDelay: '0.2s' }} />
          <Car className="w-12 h-12 text-white/90 animate-bounce" style={{ animationDelay: '0.4s' }} />
        </motion.div>
      </div>
    </section>
  );
};

export default CallToAction;

