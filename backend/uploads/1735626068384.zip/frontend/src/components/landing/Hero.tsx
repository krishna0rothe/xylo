import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import DottedBackground from './DottedBackground';

const Hero: React.FC = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <DottedBackground />
      <div
        className="absolute inset-0 bg-white/50 backdrop-blur-sm"
        style={{ transform: `translateY(${scrollY * 0.5}px)` }}
      />
      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-6xl font-bold mb-4 text-gray-800"
        >
          Get Back on the Road Faster with FixMyRide
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl md:text-2xl mb-8 text-gray-700"
        >
          Your on-demand solution for vehicle emergencies, connecting you to skilled mechanics anytime, anywhere.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="space-x-4"
        >
          <button className="bg-blue-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors duration-300">
            Request Assistance Now
          </button>
          <button className="bg-gray-200/80 backdrop-blur-sm text-gray-800 px-6 py-3 rounded-full text-lg font-semibold hover:bg-gray-300/80 transition-colors duration-300">
            Learn How It Works
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;

