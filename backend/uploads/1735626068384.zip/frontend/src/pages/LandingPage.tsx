import React from 'react';
import Hero from '../components/landing/Hero';
import HowItWorks from '../components/landing/HowItWorks';
import KeyFeatures from '../components/landing/KeyFeatures';
import CallToAction from '../components/landing/CTA';
import DottedBackground from '../components/landing/DottedBackground';
import Navigation from '../components/landing/Navigation';

const LandingPage: React.FC = () => {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <DottedBackground />
      <Navigation />
      <Hero />
      <HowItWorks />
      <KeyFeatures />
      <CallToAction />
    </div>
  );
};

export default LandingPage;

