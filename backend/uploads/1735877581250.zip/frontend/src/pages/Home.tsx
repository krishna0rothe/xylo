import { useEffect, useState } from 'react'
import { Background } from '../component/Background'
import { Header } from '../component/Header'
import { Hero } from '../component/Hero'
import { FeatureSection } from '../component/FeatureSection'

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen overflow-hidden">
      <Background />
      <Header />
      <main>
        <Hero />
        <FeatureSection />
      </main>
    </div>
  )
}

