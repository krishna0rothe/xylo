import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Wrench, User, Menu, X } from 'lucide-react'
import { NavLink } from './NavLink'

export function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem('token')
    setIsLoggedIn(!!token)
  }, [])

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  return (
    <header className="relative z-10 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Wrench className="h-6 w-6 text-blue-600 rotate-45" />
          <span className="text-xl font-semibold">FixMyRide</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/contact">Contact</NavLink>
          {isLoggedIn ? (
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <Link to="/profile">
                <User className="mr-2 h-4 w-4" />
                Profile
              </Link>
            </Button>
          ) : (
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <Link to="/login">Login</Link>
            </Button>
          )}
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-gray-500 hover:text-gray-700 focus:outline-none"
          onClick={toggleMobileMenu}
        >
          {isMobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden bg-white shadow-lg"
          >
            <div className="container mx-auto px-4 py-4 space-y-4">
              <NavLink to="/services" onClick={toggleMobileMenu}>Services</NavLink>
              <NavLink to="/about" onClick={toggleMobileMenu}>About</NavLink>
              <NavLink to="/contact" onClick={toggleMobileMenu}>Contact</NavLink>
              {isLoggedIn ? (
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                  <Link to="/profile" onClick={toggleMobileMenu}>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </Link>
                </Button>
              ) : (
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                  <Link to="/login" onClick={toggleMobileMenu}>Login</Link>
                </Button>
              )}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  )
}

