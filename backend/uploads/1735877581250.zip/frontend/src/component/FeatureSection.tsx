import { Wrench, Car, Phone } from 'lucide-react'
import { FeatureCard } from './FeatureCard'

export function FeatureSection() {
  return (
    <section className="container mx-auto px-4 py-20 relative z-10">
      <div className="grid md:grid-cols-3 gap-8">
        <FeatureCard
          icon={<Wrench className="h-6 w-6 text-blue-600" />}
          title="Expert Mechanics"
          description="Our certified mechanics bring years of experience right to your doorstep."
          delay={0.2}
        />
        <FeatureCard
          icon={<Car className="h-6 w-6 text-blue-600" />}
          title="On-Site Service"
          description="We come to you, saving you time and the hassle of towing."
          delay={0.4}
        />
        <FeatureCard
          icon={<Phone className="h-6 w-6 text-blue-600" />}
          title="24/7 Support"
          description="Round-the-clock assistance for all your vehicle emergencies."
          delay={0.6}
        />
      </div>
    </section>
  )
}

