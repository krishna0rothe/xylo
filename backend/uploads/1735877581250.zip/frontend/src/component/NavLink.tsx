import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

interface NavLinkProps {
  to: string
  children: React.ReactNode
  onClick?: () => void
}

export function NavLink({ to, children, onClick }: NavLinkProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Link
        to={to}
        className="block text-gray-600 hover:text-gray-900 transition-colors"
        onClick={onClick}
      >
        {children}
      </Link>
    </motion.div>
  )
}

