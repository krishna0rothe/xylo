
import { motion } from 'framer-motion'
import { Card } from "@/components/ui/card"

interface FeatureCardProps {
  icon: React.ReactNode
  title: string
  description: string
  delay: number
}

export function FeatureCard({ icon, title, description, delay }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
        <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
          {icon}
        </div>
        <h2 className="text-xl font-bold mb-4">{title}</h2>
        <p className="text-gray-600">{description}</p>
      </Card>
    </motion.div>
  )
}

