import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="container mx-auto px-4 py-20 text-center relative z-10">
      <motion.h1
        className="text-4xl md:text-6xl font-bold tracking-tight mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Your On-Demand Vehicle{" "}
        <span className="text-blue-600">Repair Solution</span>
      </motion.h1>
      <motion.p
        className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        Get instant access to skilled mechanics for on-site repairs. We bring
        the workshop to you.
      </motion.p>
      <motion.div
        className="flex flex-col sm:flex-row items-center justify-center gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
          Book a Mechanic
        </Button>
        <Button
          size="lg"
          variant="outline"
          className="border-2 text-lg px-8"
        >
          Learn More
        </Button>
      </motion.div>
    </section>
  )
}

