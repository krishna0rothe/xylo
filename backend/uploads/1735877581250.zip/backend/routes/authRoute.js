const express = require('express');
const { registerUser,registerMechanic, loginUser } = require('../controller/authController');
const router = express.Router();

router.post('/registerUser',registerUser)
router.post('/registerMechanic',registerMechanic)
router.post('/loginUser',loginUser)

module.exports = router;