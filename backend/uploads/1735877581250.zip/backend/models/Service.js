const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
  id: { type: mongoose.Schema.Types.ObjectId, unique: true },
  name: { type: String, required: true },
  description: { type: String },
  basePrice: { type: Number, required: true },
  durationEstimate: { type: String }
});

const Service = mongoose.model('Service', serviceSchema);
module.exports = Service;
