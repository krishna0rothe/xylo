const mongoose = require('mongoose');

const mechanicSchema = new mongoose.Schema({
  id: { type: mongoose.Schema.Types.ObjectId, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String, required: true },
  specialization: { type: Array, required: true },
  location: {
    latitude: { type: Number, },
    longitude: { type: Number, }
  },
  availabilityStatus: { type: String, enum: ['online', 'offline'], default: 'offline' },
  rating: { type: Number, default: 0 },
  completedBookings: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Booking' }],
  profileImage: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const Mechanic = mongoose.model('Mechanic', mechanicSchema);
module.exports = Mechanic;