const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  id: { type: mongoose.Schema.Types.ObjectId, unique: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  mechanicId: { type: mongoose.Schema.Types.ObjectId, ref: 'Mechanic', required: true },
  serviceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
  categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  status: { type: String, enum: ['pending', 'in progress', 'completed', 'cancelled'], default: 'pending' },
  price: { type: Number, required: true },
  location: {
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true }
  },
  requestedAt: { type: Date, default: Date.now },
  completedAt: { type: Date },
  feedback: { type: String }
});

const Booking = mongoose.model('Booking', bookingSchema);
module.exports = Booking;