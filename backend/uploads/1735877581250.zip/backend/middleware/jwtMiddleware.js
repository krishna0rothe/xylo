const jwt = require("jsonwebtoken");
const { jwtSecret } = require("../config/dotenv");

// Secret key for JWT signing
const JWT_SECRET = jwtSecret;

const jwtMiddleware = (req, res, next) => {
  try {
    // Check if the Authorization header is provided
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer")) {
      return res.status(401).json({
        status: "failed",
        message: "Authorization token is required.",
      });
    }

    // Extract the token from the header
    const token = authHeader.split(" ")[1];

    // Verify and decode the token
    const decoded = jwt.verify(token, JWT_SECRET);

    // Attach decoded data to the request object for further use
  

    // Proceed to the next middleware or route handler
    next();
  } catch (error) {
    console.error("JWT Middleware Error:", error);

    // Handle specific JWT errors
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        status: "failed",
        message: "Token has expired.",
      });
    }

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        status: "failed",
        message: "Invalid token.",
      });
    }

    // General error response
    res.status(500).json({
      status: "failed",
      message: "Internal server error during token verification.",
    });
  }
};

module.exports = jwtMiddleware;
