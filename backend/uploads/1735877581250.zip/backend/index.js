const app =require('./app')
const {port} = require('./config/dotenv')

app.listen(port,()=>console.log(`http://localhost:${port}`))