// utils/jwt.js
const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/dotenv');

// Function to generate JWT Token
const generateToken = (user) => {
  // Destructure the user object to include only id and email
  const { id, email } = user;

  // Generate JWT token with a 1-day expiration time
  const token = jwt.sign(
    { id, email }, // Payload
    jwtSecret,     // Secret key from environment variables
    { expiresIn: '1d' } // Token expiration time
  );

  return token;
};

module.exports = { generateToken };
