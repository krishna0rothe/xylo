// utils/existingUser.js
const User = require('../models/user');
const Mechanic = require('../models/mechanic');

const existingUser = async (email) => {
  const userExists = await User.findOne({ email });
  const mechanicExists = await Mechanic.findOne({ email });
  return userExists || mechanicExists;
};

module.exports = { existingUser };
