// controllers/register.js
const bcrypt = require('bcrypt');
const User = require('../models/user');
const Mechanic = require('../models/mechanic');
const { generateToken } = require('../utils/jwtUtil');
const { existingUser } = require('../utils/existingUser');

// Register a new user
const registerUser = async (req, res) => {
  try {
    const { name, email, password, phone, address } = req.body;

    // Check if user already exists in either role
    const role = await existingUser(email);
    if (role) {
      return res.status(400).json({ message: `Email is already registered as a ${role}` });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create and save new user
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
      phone,
      address
    });

    await newUser.save();

    // Generate token
    const token = generateToken({ id: newUser._id, email: newUser.email });

    res.status(201).json({ message: 'User registered successfully', token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error registering user' });
  }
};

// Register a new mechanic
const registerMechanic = async (req, res) => {
  try {
    const { name, email, password, phone, address, specialization } = req.body;

    // Check if user already exists in either role
    const role = await existingUser(email);
    if (role) {
      return res.status(400).json({ message: `Email is already registered as a ${role}` });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create and save new mechanic
    const newMechanic = new Mechanic({
      name,
      email,
      password: hashedPassword,
      phone,
      address,
      specialization
    });

    await newMechanic.save();

    // Generate token
    const token = generateToken({ id: newMechanic._id, email: newMechanic.email });

    res.status(201).json({ message: 'Mechanic registered successfully', token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error registering mechanic' });
  }
};

// Login controller
const loginUser = async (req, res) => {
    try {
      const { email, password } = req.body;
  
      // Check if the user exists (either User or Mechanic)
      const user = await existingUser(email);
  
      if (!user) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }
  
      // Compare the provided password with the hashed password in the database
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }
  
      // Generate JWT token using the existing utility function
      const token = generateToken(user);
  
      // Return the response with token and user info
      res.status(200).json({
        message: 'Login successful',
        token,
        user: { 
          id: user._id, 
          name: user.name, 
          email: user.email,
          role: user.constructor.modelName // This will return either 'User' or 'Mechanic'
        }
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error logging in user' });
    }
  };

module.exports = { registerUser, registerMechanic,loginUser };
