const express = require('express')
const cors = require('cors')
const morgan = require('morgan');
const connectDB = require("./config/database")
const app = express();
const authRoute = require("./routes/authRoute")


app.use(express.json()); // Parse JSON bodies
app.use(morgan("dev")); // Logging HTTP requests
app.use(cors()); // Enable CORS


// Connect to the database
connectDB();

app.use("/auth" , authRoute)

module.exports = app ;