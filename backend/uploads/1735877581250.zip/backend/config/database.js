const mongoose = require('mongoose');
const {mongoDBURL} = require("../config/dotenv")
// Function to connect to MongoDB
const connectDB = async () => {
  try {
    // Get the MongoDB connection string from the environment variables
    const mongoURI = mongoDBURL

    if (!mongoURI) {
      throw new Error('MongoDB connection URI is not defined in environment variables.');
    }

    // Connect to MongoDB
    const conn = await mongoose.connect(mongoURI);

    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1); // Exit process with failure
  }
};

module.exports = connectDB;
