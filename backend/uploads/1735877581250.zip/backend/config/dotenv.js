require('dotenv').config()

module.exports={
    port : process.env.PORT || 5000,
    jwtSecret : process.env.JWT_SECRET || "heyrathead",
    mongoDBURL : process.env.MONGODB_URL || "mongodb://localhost:27017/DoorStep",
}